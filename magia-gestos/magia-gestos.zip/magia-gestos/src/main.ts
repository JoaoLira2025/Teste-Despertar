import { HandTracker, type Hand } from "./tracking/handTracker";

const video = document.getElementById("video") as HTMLVideoElement;
const canvas = document.getElementById("overlay") as HTMLCanvasElement;
const ctx = canvas.getContext("2d")!;
const statusEl = document.getElementById("status")!;
const startBtn = document.getElementById("start") as HTMLButtonElement;

// Conexões entre os 21 landmarks da mão (esqueleto)
const CONNECTIONS: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
];

function drawHand(hand: Hand): void {
  const w = canvas.width;
  const h = canvas.height;
  ctx.strokeStyle = "#8f7bff";
  ctx.lineWidth = 3;
  for (const [a, b] of CONNECTIONS) {
    ctx.beginPath();
    ctx.moveTo(hand[a].x * w, hand[a].y * h);
    ctx.lineTo(hand[b].x * w, hand[b].y * h);
    ctx.stroke();
  }
  ctx.fillStyle = "#ffffff";
  for (const p of hand) {
    ctx.beginPath();
    ctx.arc(p.x * w, p.y * h, 4, 0, Math.PI * 2);
    ctx.fill();
  }
}

async function start(): Promise<void> {
  startBtn.disabled = true;
  statusEl.textContent = "Carregando modelo de mãos...";

  const tracker = new HandTracker();
  await tracker.init();

  statusEl.textContent = "Pedindo acesso à câmera...";
  const stream = await navigator.mediaDevices.getUserMedia({
    video: { width: 1280, height: 960, facingMode: "user" },
  });
  video.srcObject = stream;
  await video.play();

  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  startBtn.style.display = "none";
  statusEl.textContent = "Mostre suas mãos para a câmera";

  const loop = (): void => {
    const hands = tracker.detect(video);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    hands.forEach(drawHand);
    statusEl.textContent = `Mãos detectadas: ${hands.length}`;
    requestAnimationFrame(loop);
  };
  loop();
}

startBtn.addEventListener("click", () => {
  start().catch((err) => {
    console.error(err);
    statusEl.textContent = `Erro: ${err.message}`;
    startBtn.disabled = false;
  });
});
